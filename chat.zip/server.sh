#!/bin/bash
java -jar target/chat-jar-with-dependencies.jar server
